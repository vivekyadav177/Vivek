# V-DdoS<h1 style="color:red" align="center">What is V-DdoS tool?</h1>
<div>
<p style="color:black"><b><i><u>Distributed Denial Of Service</u></i> (DDoS) attacks are a subclass of denial of service (DoS) attacks. A DDoS attack involves multiple connected online devices, collectively known as a botnet, which are used to overwhelm a target website with fake traffic.</b></p>
<img src="https://cdn.discordapp.com/attachments/870740780938047520/870740893093724240/20210731_005139.jpg">
<p style="color:80% black"><b>This is a python coded tool for ddos attacks.. you can easily give ddos attacks in your target websites with</b> `Termux` <b>in your Android Device!! Just Follow The Steps And Setup Your Tool!! ( Scroll up for more info) </b> 
<br>
<h1 align="center" style="color:red">!!Warning!! <h1>

`Note: THIS TOOL IS JUST ONLY FOR EDUCATIONAL PURPOSE..GIVING DDOS ATTACKs WITHOUT SITE OWNER'S PERMISSION IS ILLEGAL.. SO USE IT AT YOUR OWN RISK.. WE'LL BE NOT RESPONSIBLE FOR ANY TYPES OF MISISSUES!!!`

<h1 style="color:red" align="center"> How To Install V-DdoS In Termux</h1>

<p><b>The Tool Installation Process Is Very Easy.. Just Open Your Termux & Type This Provided Commands!!</b></p>

- $ `apt update && apt upgrade`
- $ `pkg install python`
- $ `pkg install python2`
- $ `pkg install git`
- $ `pkg install figlet`
- $ `git clone https://www.github.com/T34mV18rs/V-DdoS.git`
- $ `cd V-DdoS`
- $ `chmod +x V-DdoS.py`
- $ `python2 V-DdoS.py`

<p><b>To Run</b></p>

- $ `cd V-DdoS`
- $ `python2 V-DdoS.py`

<p><b><i> Your Tool Install & Setup Done!!..Now Go To Google & Search</i></b>`Website IP Finder`<b><i>Now  Open The 1st Wesite & Place Your Target Website Url e.g. www.biribaba.com..</b></i></p>

<p><b><i>After Getting The Website IP , Copy The IP & Come To The Termux.. Now Paste The Target Website IP On</b></i> `Ip Target:` <b><i>& Give The Port Number</b></i> `8080` </p>

<p><b> Booom!! Your Ddos Attack Had Been Started...</b> </p>
<div>
<h1 style="color:red" align="center"> About Us </h1>

<img src="https://cdn.discordapp.com/attachments/870740780938047520/871007159150837820/20210610_164346.jpg">

<p><b>T34m V18rs ( Team Virus ) is a Bangladeshi FB Spamming & Termux Hacker Group..We make working tools for termux..You can reach us by visiting this links.. Thank You So Much For Using Our Tool(s)</b></p>

<p style="color:purple"><b>Connect With Us:</b></p>

``(Tap To Redirect)``

[![Github](https://img.shields.io/badge/Facebook-FBGroup-blue?style=for-the-badge&logo=facebook)](https://facebook.com/groups/mohinhossen)
[![Github](https://img.shields.io/badge/Facebook-FBPAGE-blue?style=for-the-badge&logo=facebook)](https://facebook.com/TeamVirusOfficial)
[![Github](https://img.shields.io/badge/TELEGRAM-TgGroup-orange?style=for-the-badge&logo=telegram)](https://t.me/Crackerspace)

<h3 style="color:purple"> THANKS FOR USING OUR TOOL </h3>

``©T34mV18rs``

